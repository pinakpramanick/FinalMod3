package com.cg.helper;

public class CollectionHelper {
	public void addID(int id){
		System.out.println("updated");
	}
	public void addName(String name){
		System.out.println("updated");
	}
	public void addPrice(double price){
		System.out.println("updated");
	}
	public void addTxnID(double txnID){
		System.out.println("updated");
	}
}
