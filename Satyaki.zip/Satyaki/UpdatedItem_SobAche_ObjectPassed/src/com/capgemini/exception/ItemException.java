package com.capgemini.exception;
import java.lang.Exception;
public class ItemException extends Exception{

	
	public ItemException()
	{
		System.out.println(" Invalid Input");

	}
	
}
