package com.cg.exception;

import java.lang.Exception;
public class MyException extends Exception {
	public MyException(){
		System.out.println("Inavlid Input");
	}
}
